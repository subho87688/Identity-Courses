Problem Statement : Identify Courses
 
 
Search and display all web development courses 
	1. Should be for beginners level.
	2. Courses offered in English language
	3. Display first two courses with name, total learning hours and rating.

	
Extract all the languages and different levels
	1. Mark the Language learning check box.
	2. Extract all the language visible
	3. Extract all the Levels Visible

	
Enquiry Form Validation
	1. In Home page, go to "For Enterprise".
	2. Look into Coursera for Campus under Solutions
	3. Fill the  "Get in touch with our sales team" form with any one input invalid (example: email)
	4. Capture the error message & display




Key Automation Scope :
 
	Handling different browser windows, search option
	Extract multiple drop down list items & store in collections
	Navigating back to home page
	Filling form (in different objects in web page)
	Capture warning message
	Scrolling down in web page